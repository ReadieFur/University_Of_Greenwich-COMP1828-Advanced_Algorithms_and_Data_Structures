### This folder contains the main source code for coursework tasks.
